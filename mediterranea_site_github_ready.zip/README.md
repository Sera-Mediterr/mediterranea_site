# Mediterranea Property Consulting

Static website for **Mediterranea Property Consulting - by Serafina LOGGIA**.

### How to publish on GitHub Pages
1. Go to your repository on GitHub.
2. Click on **Settings → Pages**.
3. Under *Build and deployment*, choose:
   - Source: **Deploy from a branch**
   - Branch: **main / (root)**
4. Save. Wait 1–2 minutes. Your site will be live.
// Translation dictionary for ALL page texts
const i18n = {
  fr: {
    nav_about: "À propos",
    nav_services: "Services",
    nav_contact: "Contact",
    hero_tag: "Méditerranée · Immobilier · Relocation",
    hero_title_l1: "MEDITERRANEA PROPERTY CONSULTING",
    hero_title_l2: "PROPERTY CONSULTING -by Serafina LOGGIA",
    hero_sub: "Conseil immobilier, accompagnement à l’achat/vente, et installation en France et en Italie.",
    email_btn: "E‑mail",
    linkedin: "LinkedIn",
    instagram: "Instagram",
    whatsapp: "WhatsApp",
    about_h: "À propos",
    about_p: "Accompagnement sur-mesure pour vos projets immobiliers entre la France et l’Italie : recherche, visites, négociation, due diligence et installation.",
    services_h: "Services",
    s1_h: "Achat & Vente",
    s1_p: "Recherche ciblée, estimation, mise en relation et pilotage jusqu’à l’acte.",
    s2_h: "Relocation",
    s2_p: "Installation clé en main : logement, démarches, écoles, mobilité.",
    s3_h: "Conseil",
    s3_p: "Audit de projet, second avis, stratégies d’investissement.",
    contact_h: "Contact",
    contact_p: "Écrivez-moi pour décrire votre projet. Je reviens vers vous rapidement.",
    reveal_copy: "Copier",
    copied: "Copié !",
    footer: "© 2025 Mediterranea Property Consulting. Tous droits réservés."
  },
  it: {
    nav_about: "Chi sono",
    nav_services: "Servizi",
    nav_contact: "Contatti",
    hero_tag: "Mediterraneo · Immobiliare · Relocation",
    hero_title_l1: "MEDITERRANEA PROPERTY CONSULTING",
    hero_title_l2: "PROPERTY CONSULTING -by Serafina LOGGIA",
    hero_sub: "Consulenza immobiliare, supporto all’acquisto/vendita e relocation in Francia e in Italia.",
    email_btn: "E‑mail",
    linkedin: "LinkedIn",
    instagram: "Instagram",
    whatsapp: "WhatsApp",
    about_h: "Chi sono",
    about_p: "Accompagnamento su misura per i vostri progetti immobiliari tra Francia e Italia: ricerca, visite, negoziazione, due diligence e insediamento.",
    services_h: "Servizi",
    s1_h: "Acquisto & Vendita",
    s1_p: "Ricerca mirata, stima, contatti e gestione fino all’atto.",
    s2_h: "Relocation",
    s2_p: "Insediamento chiavi in mano: casa, pratiche, scuole, mobilità.",
    s3_h: "Consulenza",
    s3_p: "Audit del progetto, second opinion, strategie d’investimento.",
    contact_h: "Contatti",
    contact_p: "Scrivetemi per descrivere il vostro progetto. Vi risponderò al più presto.",
    reveal_copy: "Copia",
    copied: "Copiato!",
    footer: "© 2025 Mediterranea Property Consulting. Tutti i diritti riservati."
  },
  en: {
    nav_about: "About",
    nav_services: "Services",
    nav_contact: "Contact",
    hero_tag: "Mediterranean · Real Estate · Relocation",
    hero_title_l1: "MEDITERRANEA PROPERTY CONSULTING",
    hero_title_l2: "PROPERTY CONSULTING -by Serafina LOGGIA",
    hero_sub: "Real estate advisory, buy/sell support, and relocation across France and Italy.",
    email_btn: "E‑mail",
    linkedin: "LinkedIn",
    instagram: "Instagram",
    whatsapp: "WhatsApp",
    about_h: "About",
    about_p: "Bespoke support for your real estate projects between France and Italy: search, viewings, negotiation, due diligence, and settling in.",
    services_h: "Services",
    s1_h: "Buy & Sell",
    s1_p: "Targeted search, valuation, introductions, and guidance through closing.",
    s2_h: "Relocation",
    s2_p: "Turn‑key settling: housing, paperwork, schools, mobility.",
    s3_h: "Advisory",
    s3_p: "Project audit, second opinion, investment strategies.",
    contact_h: "Contact",
    contact_p: "Write to me about your project. I’ll get back to you shortly.",
    reveal_copy: "Copy",
    copied: "Copied!",
    footer: "© 2025 Mediterranea Property Consulting. All rights reserved."
  }
};

const els = (sel) => Array.from(document.querySelectorAll(sel));
const setLang = (lang) => {
  const dict = i18n[lang] || i18n.fr;
  els('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (dict[key] !== undefined) el.innerText = dict[key];
  });
  document.querySelectorAll('.lang-switch button').forEach(b => b.classList.toggle('active', b.dataset.lang===lang));
  localStorage.setItem('lang', lang);
};

document.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('lang') || 'fr';
  setLang(saved);

  // Email reveal/copy behavior
  const emailBtn = document.getElementById('email-btn');
  const emailBox = document.getElementById('email-box');
  const emailText = document.getElementById('email-text');
  const copyBtn = document.getElementById('copy-btn');
  const EMAIL = 'MediterraneaPropertyConsulting@proton.me';
  let hideTimer;
  emailBtn.addEventListener('click', () => {
    emailText.textContent = EMAIL;
    emailBox.style.display = 'block';
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => { emailBox.style.display='none'; }, 5000);
  });
  copyBtn.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(EMAIL);
      const original = copyBtn.innerText;
      copyBtn.innerText = i18n[localStorage.getItem('lang')||'fr'].copied;
      setTimeout(()=> copyBtn.innerText = i18n[localStorage.getItem('lang')||'fr'].reveal_copy, 1200);
    } catch(e){ console.warn(e); }
  });

  // Social links
  document.getElementById('lnk-linkedin').href = 'https://www.linkedin.com/in/serafinal/';
  document.getElementById('lnk-instagram').href = 'https://www.instagram.com/mediterraneapropertyco/';
  document.getElementById('lnk-whatsapp').href = 'https://wa.me/33781649929'; // sanitized E.164
});